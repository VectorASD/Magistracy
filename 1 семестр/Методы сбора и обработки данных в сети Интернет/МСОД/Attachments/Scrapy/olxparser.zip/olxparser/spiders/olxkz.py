import scrapy
from scrapy.http import HtmlResponse
from olxparser.items import OlxparserItem
from scrapy.loader import ItemLoader

class OlxkzSpider(scrapy.Spider):
    name = 'olxkz'
    allowed_domains = ['olx.kz']


    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.start_urls = [f'https://www.olx.kz/d/list/q-{kwargs.get("search")}/']

    def parse(self, response: HtmlResponse):
        links = response.xpath("//h6/ancestor::a")
        for link in links:
            yield response.follow(link, callback=self.parse_ads)

        #TODO:
        # Pagination

    def parse_ads(self, response: HtmlResponse):
        loader = ItemLoader(item=OlxparserItem(), response=response)
        loader.add_xpath('name', "//h1/text()")
        loader.add_xpath('price', "//h3/text()")
        loader.add_xpath('photos', "//div[@class='swiper-zoom-container']/img/@src | //div[@class='swiper-zoom-container']/img/@data-src")
        loader.add_value('url', response.url)
        yield loader.load_item()



        # name = response.xpath("//h1/text()").get()
        # price = response.xpath("//h3/text()").get()    # response.xpath("//div[@data-testid='ad-price-container']/h3/text()").getall()
        # photos = response.xpath("//div[@class='swiper-zoom-container']/img/@src | //div[@class='swiper-zoom-container']/img/@data-src ").getall()
        # yield OlxparserItem(name=name, price=price, photos=photos)
